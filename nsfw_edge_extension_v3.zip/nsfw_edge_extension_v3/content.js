// === CONFIG ===
const pervertSoundURL = "https://github.com/shayeviney/mp3/raw/c2ab453d0ce782923f06c1499e5ae1224eda6f1a/no-perverts.mp3";
const audioVolume = 0.6;

// === WHITELIST ===
const whitelist = [
  "google.com",
  "instagram.com",
  "youtube.com",
  "twitter.com",
  "linkedin.com"
];

// === CHECK IF CURRENT SITE IS SAFE ===
function isWhitelisted() {
  return whitelist.some(domain => window.location.hostname.includes(domain));
}

// === SKIP ENTIRE SCRIPT IF SAFE SITE ===
if (!isWhitelisted()) {

  // === CREATE AUDIO ELEMENT ===
  const hoverAudio = new Audio(pervertSoundURL);
  hoverAudio.volume = audioVolume;

  // === BLUR / UNBLUR FUNCTIONS ===
  function blurImage(el) {
    el.style.filter = "blur(15px)";
    el.dataset.blurred = "true";
  }

  function unblurImage(el) {
    el.style.filter = "none";
    el.dataset.blurred = "false";
  }

  function toggleImage(el) {
    if (el.dataset.blurred === "true") unblurImage(el);
    else blurImage(el);
  }

  // === HOVER SOUND ===
  function attachHoverSound(el) {
    el.addEventListener("mouseenter", () => {
      if (el.dataset.blurred === "true") {
        hoverAudio.currentTime = 0;
        hoverAudio.play().catch(() => {});
      }
    });
  }

  // === INITIALIZE IMAGE ===
  function initImage(el) {
    if (!el.dataset.inited) {
      blurImage(el);
      attachHoverSound(el);

      // click toggle only for full-page images
      if (!el.closest(".thumbnail, .lazy")) {
        el.style.cursor = "pointer";
        el.addEventListener("click", () => toggleImage(el));
      }

      el.dataset.inited = "true";
    }
  }

  // === INITIALIZE ALL IMAGES ===
  function initImages() {
    document.querySelectorAll("img").forEach(initImage);
  }

  // === GUI BUTTON ===
  const guiBtn = document.createElement("button");
  guiBtn.style.position = "fixed";
  guiBtn.style.bottom = "20px";
  guiBtn.style.right = "20px";
  guiBtn.style.zIndex = 9999;
  guiBtn.style.padding = "10px 15px";
  guiBtn.style.backgroundColor = "#f44336"; // red
  guiBtn.style.color = "#fff";
  guiBtn.style.border = "none";
  guiBtn.style.borderRadius = "5px";
  guiBtn.style.cursor = "pointer";
  guiBtn.innerText = "Unblur All";
  let isAllUnblurred = false;

  guiBtn.addEventListener("click", () => {
    document.querySelectorAll("img").forEach(el => {
      if (isAllUnblurred) blurImage(el);
      else unblurImage(el);
    });

    isAllUnblurred = !isAllUnblurred;
    guiBtn.innerText = isAllUnblurred ? "Blur All" : "Unblur All";
    guiBtn.style.backgroundColor = isAllUnblurred ? "#4caf50" : "#f44336";
  });

  document.body.appendChild(guiBtn);

  // === RUN INIT ON LOAD ===
  initImages();

  // === OBSERVE DYNAMIC IMAGES (lazy load) ===
  const observer = new MutationObserver(initImages);
  observer.observe(document.body, { childList: true, subtree: true });
}
